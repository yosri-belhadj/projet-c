#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include <glib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verification.h"
#include "string.h"


void
on_Login_clicked                       (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{


  GtkWidget *input1;  
  GtkWidget *input2;
  GtkWidget *output;
  GtkWidget *acceuil; 
  GtkWidget *espaceadmin;
  GtkWidget *espaceagent;
   GtkWidget *espaceclient;
  char login[20];
  char password[20];
  int ver;
  
  input1=lookup_widget(objet_graphique,"loginUsernameEntry");
  strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));

  input2=lookup_widget(objet_graphique,"loginPasswordEntry"); 
  strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

  output=lookup_widget(objet_graphique,"errorLabel");
  ver=verifier(login,password);

switch(ver)
{
	case 1://pour afficher(espace admin)
		espaceadmin= create_espaceadmin();
		gtk_widget_show (espaceadmin);
		acceuil =lookup_widget(objet_graphique,"acceuil");
		gtk_widget_hide(acceuil);
		break;
case 2://pour afficher(espace agent)
		espaceagent= create_espaceagent();
		gtk_widget_show (espaceagent);
		acceuil =lookup_widget(objet_graphique,"acceuil");
		gtk_widget_hide(acceuil);
		break;
case 3://pour afficher(espace client)
		espaceclient= create_espaceclient();
		gtk_widget_show (espaceclient);
		acceuil =lookup_widget(objet_graphique,"acceuil");
		gtk_widget_hide(acceuil);
		break;

	default :
gtk_label_set_text(GTK_LABEL(output),"veuillez vérifier vos paramètres !");
}}



void
on_inscription_clicked                 (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	GtkWidget *fenetre_inscription;
	fenetre_inscription= create_fenetre_inscription();
		gtk_widget_show (fenetre_inscription);
		acceuil =lookup_widget(objet_graphique,"acceuil");
		gtk_widget_hide(acceuil);
}

void on_ajouter_clicked(GtkWidget     *objet_graphique, gpointer   user_data)
{

	
char nom[20];
char adresse [20];
char prenom[20];
char pays[20];
char nom_dutilisateur[20];
char mot_de_passe[20];
char telephone[20];
char email[20];




        GtkWidget *entry1;
 	GtkWidget *entry2;
	GtkWidget *entry3;
        GtkWidget *entry4;
        GtkWidget *entry5;
        GtkWidget *entry6;
        GtkWidget *entry7;
        GtkWidget *entry8;
	GtkWidget *fenetre_inscription;
        GtkWidget *espaceclient;
	espaceclient= create_espaceclient();

		gtk_widget_show (espaceclient);
        fenetre_inscription=lookup_widget(objet_graphique,"fenetre_inscription");
		gtk_widget_hide(fenetre_inscription);
	
        fenetre_inscription=lookup_widget(objet_graphique,"fenetre_inscription");

	
	entry1=lookup_widget(objet_graphique,"entry1");
        entry2=lookup_widget(objet_graphique,"entry2");
        entry3=lookup_widget(objet_graphique,"entry3");
        entry4=lookup_widget(objet_graphique,"entry4");
        entry5=lookup_widget(objet_graphique,"entry5");
        entry6=lookup_widget(objet_graphique,"entry6");
        entry7=lookup_widget(objet_graphique,"entry7");
	entry8=lookup_widget(objet_graphique,"entry8");
        
       
	strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry1)));
	strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(entry2)));
        strcpy(adresse,gtk_entry_get_text(GTK_ENTRY(entry3)));
        strcpy(pays,gtk_entry_get_text(GTK_ENTRY(entry4)));
        strcpy(nom_dutilisateur,gtk_entry_get_text(GTK_ENTRY(entry5)));
        strcpy(mot_de_passe,gtk_entry_get_text(GTK_ENTRY(entry6)));
        strcpy(telephone,gtk_entry_get_text(GTK_ENTRY(entry7)));
        strcpy(email,gtk_entry_get_text(GTK_ENTRY(entry8)));

        inscription_client (nom,adresse,prenom,pays,nom_dutilisateur,mot_de_passe,telephone,email);
}



void
on_retour_clicked                      (GtkWidget     *objet_graphique, gpointer   user_data)
{

 GtkWidget *acceuil, *fenetre_inscription;
 fenetre_inscription=lookup_widget(objet_graphique, "fenetre_inscription");

 gtk_widget_destroy(fenetre_inscription);
 acceuil=create_acceuil();
 gtk_widget_show(acceuil);
}





void
on_agent_clicked                         (GtkWidget     *objet_graphique, gpointer   user_data)
{

 		GtkWidget *espaceagent, *gestionagent;
		gestionagent= create_gestionagent();
		gtk_widget_show (gestionagent);
		espaceagent =lookup_widget(objet_graphique,"espaceagent");
		gtk_widget_hide(espaceagent);
}

//new


void
on_afficher_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data)

{

  GtkWidget *gestionagent;
  GtkWidget *treeview1;
  gestionagent=lookup_widget(objet_graphique,"gestionagent");
  treeview1=lookup_widget(gestionagent,"treeview1");
  afficheremploye(treeview1);

}



void
on_ajouteragent_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
agent a;  
  GtkWidget *input1;  
  GtkWidget *input2; 
  GtkWidget *input3;  
  GtkWidget *input4;  
  GtkWidget *input5;  
  GtkWidget *input6;  
  GtkWidget *input7;  
  GtkWidget *input8; 
  GtkWidget *input9;
  GtkWidget *input10;
  GtkWidget *radiobutton1;
  GtkWidget *radiobutton2;

  input1=lookup_widget(objet_graphique,"entry3"); 
  input2=lookup_widget(objet_graphique,"entry4"); 
  radiobutton1=lookup_widget(objet_graphique,"radiobutton1"); 
  radiobutton2=lookup_widget(objet_graphique,"radiobutton2"); 
  input5=lookup_widget(objet_graphique,"spinbutton1"); 
  input6=lookup_widget(objet_graphique,"spinbutton2"); 
  input7=lookup_widget(objet_graphique,"spinbutton3"); 
  input8=lookup_widget(objet_graphique,"spinbutton4");
  input9=lookup_widget(objet_graphique,"spinbutton5"); 
  input10=lookup_widget(objet_graphique,"spinbutton11"); 
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
  {strcpy(a.couleur,"Noir");;}
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
  {strcpy(a.couleur,"Blanc");;}
  strcpy(a.marque,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(a.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(a.jours,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(a.chevaux,gtk_entry_get_text(GTK_ENTRY(input6)));
  strcpy(a.jour,gtk_entry_get_text(GTK_ENTRY(input7)));
  strcpy(a.mois,gtk_entry_get_text(GTK_ENTRY(input8)));
  strcpy(a.annee,gtk_entry_get_text(GTK_ENTRY(input9)));
  strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input10)));
  ajouteragent(a);
}



void
on_modifieragent_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{


char marque[20] ;char matricule[20];char couleur [20];char jours[20];char chevaux[20]; char jour[20];char mois[20];char annee[20];char id[10];
 agent a;
  GtkWidget *input1;  
  GtkWidget *input2; 
  GtkWidget *input3;  
  GtkWidget *input4;  
  GtkWidget *input5;  
  GtkWidget *input6;  
  GtkWidget *input7;  
  GtkWidget *input8; 
  GtkWidget *input9;
  GtkWidget *input10;
  GtkWidget *radiobutton3;
  GtkWidget *radiobutton4;

  input1=lookup_widget(objet_graphique,"entry5"); 
  input2=lookup_widget(objet_graphique,"entry6"); 
  radiobutton3=lookup_widget(objet_graphique,"radiobutton3"); 
  radiobutton4=lookup_widget(objet_graphique,"radiobutton4"); 
  input5=lookup_widget(objet_graphique,"spinbutton6"); 
  input6=lookup_widget(objet_graphique,"spinbutton7"); 
  input7=lookup_widget(objet_graphique,"spinbutton8"); 
  input8=lookup_widget(objet_graphique,"spinbutton9");
  input9=lookup_widget(objet_graphique,"spinbutton10"); 
  input10=lookup_widget(objet_graphique,"spinbutton12"); 
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton3))==TRUE)
  {strcpy(a.couleur,"Noir");;}
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton4))==TRUE)
  {strcpy(a.couleur,"Blanc");;}
  strcpy(a.marque,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(a.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(a.jours,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(a.chevaux,gtk_entry_get_text(GTK_ENTRY(input6)));
  strcpy(a.jour,gtk_entry_get_text(GTK_ENTRY(input7)));
  strcpy(a.mois,gtk_entry_get_text(GTK_ENTRY(input8)));
  strcpy(a.annee,gtk_entry_get_text(GTK_ENTRY(input9)));
  strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input10)));
  modifieragent(a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id);
}


void
on_supprimeragent_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
  char id[20];
  GtkWidget *input1;
  input1=lookup_widget(objet_graphique,"entry7"); 
  strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
  supprimeragent(id);

}


void
on_exc_clicked                                   (GtkWidget     *objet_graphique, gpointer   user_data)
{

 		GtkWidget *espace_agent, *window1;
		window1= create_window1();
		gtk_widget_show (window1);
		espace_agent =lookup_widget(objet_graphique,"espaceagent");
		gtk_widget_hide(espace_agent);
}


///////////////////////////////////////////////


void
on_button9_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data)

{

  GtkWidget *window1;
  GtkWidget *liste;
  window1=lookup_widget(objet_graphique,"window1");
  liste=lookup_widget(window1,"treeview2");
  afficher_exc(liste);

}



void
on_button6_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
excu a;  
  GtkWidget *input1;  
  GtkWidget *input2;  
  GtkWidget *input5;  
  GtkWidget *input7;  
  GtkWidget *input8;
  
  input1=lookup_widget(objet_graphique,"entry10"); 
  input2=lookup_widget(objet_graphique,"entry11"); 
  input5=lookup_widget(objet_graphique,"spinbutton15"); 
  input7=lookup_widget(objet_graphique,"spinbutton13"); 
  input8=lookup_widget(objet_graphique,"spinbutton17"); 

  strcpy(a.destination,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(a.prix,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(a.nb_personne,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(a.nb_jours,gtk_entry_get_text(GTK_ENTRY(input7)));
  strcpy(a.iid,gtk_entry_get_text(GTK_ENTRY(input8)));
  ajouter_exc(a);
}



void
on_button7_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{


char destination[20] ;char prix[20];char nb_personne [20];char nb_jours[20];
 excu a;
  GtkWidget *input1;  
  GtkWidget *input2; 

  GtkWidget *input5;  
  GtkWidget *input6;  
  GtkWidget *input8; 
 
  input1=lookup_widget(objet_graphique,"entry12"); 
  input2=lookup_widget(objet_graphique,"entry13"); 
  input5=lookup_widget(objet_graphique,"spinbutton16"); 
  input6=lookup_widget(objet_graphique,"spinbutton14"); 
  input8=lookup_widget(objet_graphique,"spinbutton18"); 

  strcpy(a.destination,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(a.prix,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(a.nb_personne,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(a.nb_jours,gtk_entry_get_text(GTK_ENTRY(input6)));
  strcpy(a.iid,gtk_entry_get_text(GTK_ENTRY(input8)));
  modifier_exc(a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid);
}


void
on_button8_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
  char iid[20];
  GtkWidget *input1;
  input1=lookup_widget(objet_graphique,"entry14"); 
  strcpy(iid,gtk_entry_get_text(GTK_ENTRY(input1)));
  supprimer_exc(iid);

}




void
on_button10_clicked                    (GtkWidget     *objet_graphique, gpointer   user_data)
{

 GtkWidget *acceuil, *espaceclient;
 espaceclient=lookup_widget(objet_graphique, "espaceclient");

 gtk_widget_destroy(espaceclient);
 acceuil=create_acceuil();
 gtk_widget_show(acceuil);
}



void
on_button11_clicked                                   (GtkWidget     *objet_graphique, gpointer   user_data)
{

 GtkWidget *espaceagent, *gestionagent;
 gestionagent=lookup_widget(objet_graphique, "gestionagent");

 gtk_widget_destroy(gestionagent);
 espaceagent=create_espaceagent();
 gtk_widget_show(espaceagent);
}

void
on_button12_clicked                                (GtkWidget     *objet_graphique, gpointer   user_data)
{

 GtkWidget *espaceagent, *window1;
 window1=lookup_widget(objet_graphique, "window1");

 gtk_widget_destroy(window1);
 espaceagent=create_espaceagent();
 gtk_widget_show(espaceagent);
}



void
on_button13_clicked                 (GtkWidget     *objet_graphique, gpointer   user_data)
{

 GtkWidget *espaceagent, *acceuil;
 espaceagent=lookup_widget(objet_graphique, "espaceagent");

 gtk_widget_destroy(espaceagent);
 acceuil=create_acceuil();
 gtk_widget_show(acceuil);
}
