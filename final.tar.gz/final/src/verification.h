#include <gtk/gtk.h>
int verifier(char login[20], char password[20]);


typedef struct
{

char nom[20];
char adresse[20];
char prenom[20];
char pays[20];
char nom_dutilisateur[20];
char mot_de_passe[20];
char telephone[20];
char email[20];

}client;


void inscription_client(char nom[],char adresse [],char prenom[],char pays[],char nom_dutilisateur [],char mot_de_passe[],char telephone[],char email[]);
//new

enum
{MARQUE=0,
MATRICULE,
COULEUR,
JOURS,
CHEVAUX,
JOUR,
MOIS,
ANNEE,
ID,
NUM_COL
};

void afficheremploye(GtkWidget *treeview1); 
typedef struct agent 
{
char marque[20];
char matricule [20];
char couleur [20];
char  jours [10];
char chevaux [10] ;
char jour [20];
char mois[20];
char annee[20];
char id[10];

} agent ;
void ajouteragent(agent a);
void modifieragent(char marque[20],char matricule[20],char couleur [20],char jours[10],char chevaux[10],char jour[20],char mois[20],char annee[20],char id [10] );
void supprimeragent(char id[10] );
//////////////////////////////////////////////

enum
{DESTINATION=0,
PRIX,
NB_PERSONNE,
NB_JOURS,
IID,
NUM_COLL
};

void afficher_exc(GtkWidget *liste); 
typedef struct excu 
{
char destination[20];
char prix [20];
char nb_personne [20];
char  nb_jours [10];
char iid[10]
} excu ;
void ajouter_exc(excu a);
void modifier_exc(char destination[20],char prix[20],char nb_personne [20],char nb_jours[10],char iid[10]);
void supprimer_exc(char iid[10] );

// new 2


