

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "verification.h"

int verifier(char login[20], char password[20]){
FILE *f ;
int test=0;
f=fopen("users.txt","r") ;
char login1[20]; char password1[20]; int role;
if (f!=NULL) {
while ((fscanf(f,"%s %s %d",login1,password1,&role)!=EOF)) {
if ((strcmp(login1,login)==0) && (strcmp(password1,password))==0){ 
test=role;
}}
fclose(f);
}
return test;
}


enum
{
	Nom,
	Adresse,
	Prenom,
	Pays,
	Telephone,
	Email,
	Nom_dutilisateur,
	Mot_de_passe,
	COLUMNS
};

void inscription_client(char nom[],char adresse [],char prenom[],char pays[],char nom_dutilisateur [],char mot_de_passe[],char telephone[],char email[])
{
FILE *f;
f=fopen("texte.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n ",nom,adresse,prenom,
pays,telephone,email);


fclose(f);
}
{
FILE *f;
f=fopen("users.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s 3\n",nom_dutilisateur,mot_de_passe);



fclose(f);
}
}
}

//new

void afficheremploye(GtkWidget *treeview1)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter ;
GtkListStore *store ;
char marque [100];
char matricule[100] ;
char couleur [10];
char jours[10];
char chevaux [10];
char jour [10] ;
char mois [10] ;
char annee [10] ;
//
char id [10] ;
//

FILE *f ;
store =NULL ;
store=gtk_tree_view_get_model(treeview1);
if (store == NULL)
{
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("marque",renderer,"text",MARQUE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("matricule",renderer,"text",MATRICULE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("couleur",renderer,"text",COULEUR,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("jours",renderer,"text",JOURS,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);

             renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("chevaux",renderer,"text",CHEVAUX,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("Jour",renderer,"text",JOUR,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);
            
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",MOIS,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);
            
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",ANNEE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);
//

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("id",renderer,"text",ID,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1),column);
//

}
            store =gtk_list_store_new(NUM_COL,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
            f=fopen("agent.txt","r");
            if (f!=NULL){
while (fscanf(f,"%s %s %s %s %s %s %s %s %s",marque,matricule,couleur,jours,chevaux,jour,mois,annee,id)!=EOF) {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set
            (store,&iter,MARQUE,marque,MATRICULE,matricule,COULEUR,couleur,JOURS,jours,CHEVAUX,chevaux,JOUR,jour,MOIS,mois,ANNEE,annee,ID,id,-1);
}
fclose(f);
}
            gtk_tree_view_set_model(GTK_TREE_VIEW(treeview1),GTK_TREE_MODEL(store));
            g_object_unref(store);
}

void ajouteragent(agent a) {
FILE * f; 

f=fopen("agent.txt","a+") ;
if(f!=NULL) {


fprintf(f,"%s %s %s %s %s %s %s %s %s\n ",a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id );
}

fclose(f); 
}
void modifieragent(char marque[20] ,char matricule[20],char couleur [20],char jours[20],char chevaux[20] ,char jour[20],char mois[20],char annee[20],char id[10] )
{
agent a;
FILE *f;
FILE *f1;
f1=NULL ;
f=fopen("agent.txt","r+");
f1=fopen("agent1.txt","w");
if (f!= NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s\n ",a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id)!=EOF) {
if (strcmp(id ,a.id)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s \n",marque,matricule,couleur,jours,chevaux,jour,mois,annee,id) ;
}
else
fprintf(f1,"%s %s %s %s %s %s %s %s %s\n ",a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id) ;
}
fclose(f1);
fclose(f);
remove("agent.txt");
rename ("agent1.txt","agent.txt");
}
}

void supprimeragent(char id[] ){
agent a;
FILE *f;
FILE *f1 ;
f1 =NULL;
f=fopen("agent.txt","r") ;
if (f!= NULL)
{

while (fscanf(f," %s %s %s %s %s %s %s %s %s ",a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id)!=EOF) {
if (strcmp(id,a.id))
{
f1=fopen("agent1.txt","a");

fprintf(f1,"%s %s %s %s %s %s %s %s %s \n",a.marque,a.matricule,a.couleur,a.jours,a.chevaux,a.jour,a.mois,a.annee,a.id ) ;
fclose(f1);
}
}
}


fclose(f);
remove("agent.txt");
rename("agent1.txt","agent.txt");

}
//////////////////////////////////////////////////////


void afficher_exc(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter ;
GtkListStore *store ;
char destination [100];
char prix[100] ;
char nb_personne [10];
char nb_jours[10];
char iid[10];

//

FILE *f ;
store =NULL ;
store=gtk_tree_view_get_model(liste);
if (store == NULL)
{
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("destination",renderer,"text",DESTINATION,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("prix",renderer,"text",PRIX,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("nb_personne",renderer,"text",NB_PERSONNE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("nb_jours",renderer,"text",NB_JOURS,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("iid",renderer,"text",IID,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
//

}
            store =gtk_list_store_new(NUM_COLL,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
            f=fopen("exc.txt","r");
            if (f!=NULL){
while (fscanf(f,"%s %s %s %s %s ",destination,prix,nb_personne,nb_jours,iid)!=EOF) {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set
            (store,&iter,DESTINATION,destination,PRIX,prix,NB_PERSONNE,nb_personne,NB_JOURS,nb_jours,IID,iid,-1);
}
fclose(f);
}
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);
}

void ajouter_exc(excu a) {
FILE * f; 

f=fopen("exc.txt","a+") ;
if(f!=NULL) {


fprintf(f,"%s %s %s %s %s\n ",a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid );
}

fclose(f); 
}
void modifier_exc(char destination[20] ,char prix[20],char nb_personne [20],char nb_jours[20],char iid[20]  )
{
excu a;
FILE *f;
FILE *f1;
f1=NULL ;
f=fopen("exc.txt","r+");
f1=fopen("exc1.txt","w");
if (f!= NULL)
{
while (fscanf(f,"%s %s %s %s %s\n ",a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid)!=EOF) {
if (strcmp(iid ,a.iid)==0)
{
fprintf(f1,"%s %s %s %s %s  \n",destination,prix,nb_personne,nb_jours,iid) ;
}
else
fprintf(f1,"%s %s %s %s %s \n ",a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid) ;
}
fclose(f1);
fclose(f);
remove("exc.txt");
rename ("exc1.txt","exc.txt");
}
}

void supprimer_exc(char iid[] ){
excu a;
FILE *f;
FILE *f1 ;
f1 =NULL;
f=fopen("exc.txt","r") ;
if (f!= NULL)
{

while (fscanf(f," %s %s %s %s %s",a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid)!=EOF) {
if (strcmp(iid,a.iid))
{
f1=fopen("exc1.txt","a");

fprintf(f1,"%s %s %s %s %s\n",a.destination,a.prix,a.nb_personne,a.nb_jours,a.iid ) ;
fclose(f1);
}
}
}


fclose(f);
remove("exc.txt");
rename("exc1.txt","exc.txt");

}

//new 1




