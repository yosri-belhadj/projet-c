#include <gtk/gtk.h>


void
on_Login_clicked                       (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_inscription_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data);



void on_ajouter_clicked(GtkWidget *objet_graphique,gpointer user_data);


void
on_retour_clicked                        (GtkWidget     *objet_graphique,
                                        gpointer         user_data);


void
on_agent_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);
//new

void
on_afficher_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data);


void
on_ajouteragent_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data);


void
on_modifieragent_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_supprimeragent_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void on_exc_clicked        (GtkWidget     *objet_graphique, gpointer   user_data);
////////////////////////////////

void
on_button9_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data);


void
on_button6_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data);


void
on_button7_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data);



// new 1





void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
